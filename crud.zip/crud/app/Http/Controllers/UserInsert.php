<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;

class UserInsert extends Controller
{
    public function insertform()
    {

        return view('userinsert');
    }

    public function insert(Request $request)
    {
        $name = $request->input('stud_name');
        DB::insert('insert into user (name) values(?)', [$name]);
        $user = DB::select('select * from user');
        $msg =  "Record inserted successfully";
        return view('userGet', [
            'msg' => $msg,
            'user' => $user
        ]);
        // echo '<a href = "/insert">Click Here</a> to go back.';
    }

    public function read()
    {
        $user = DB::select('select * from user');
        return view('userGet', ['user' => $user]);
    }


    public function delete_rec(Request $request)
    {
        $id = $request->input('id');
        DB::table('user')->where('id', $id)->delete();
        return response()->json(['<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Success</strong> Record Deleted Successfully <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>']);
    }


    public function get_modal_data(Request $request)
    {
        $id = $request->input('id');
        // Retrieve the data for the specified ID
        $data = DB::table('user')->where('id', $id)->first();
        return view('ajax.update_body', ['data' => $data]);
    }

    public function update(Request $request)
    {
        $id = $request->input('id');
        DB::update("update user set name = '.$id.' ");
        return response()->json(['<div class="alert alert-danger alert-dismissible fade show" role="alert"> <strong>Success</strong> Record Deleted Successfully <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>']);
    }
}
