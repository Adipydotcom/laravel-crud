<html>

<head>
    <title>Student Management | Add</title>
    <!-- Bootstrap Css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>

    <div class="container">
        <div class="row">
            <h1 class="text-center mt-3 mb-3">
                Crud Application In Laravel
            </h1>
            <div id="delmsg">

            </div>
            <?php

            if (isset($msg)) {
                // echo '<div class="col-md-12 mb-3 alert alert-success" role="alert"> ' . $msg . ' </div>';
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert"> <strong>Success</strong> ' . $msg . ' <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
            }

            ?>
            <div class="col-md-12 mb-3">
                <!-- <a href="{{ url('/insert') }}" class="btn btn-success btn-sm">Add User</a> -->
                <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#adduser">
                    Add User
                </button>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Id </th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $c = 1; ?>
                    @foreach ($user as $users)
                    <tr>
                        <td><?php echo $c++ ?></td>
                        <td>{{ $users->name }}</td>
                        <td><button class="btn btn-danger btn-sm deleteuser" value="{{ $users->id }}" onclick="delt('{{ $users->id }}')" id="deleteuser">Delete</button>
                            <button type="button" class="btn btn-info btn-sm" onclick="updateUser('{{ $users->id }}')">Update</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="adduser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="{{ url('/insert') }}" method="post">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <div class="col-md-12">
                            <label>Name</label>
                            <input type='text' class="form-control" name='stud_name' />
                        </div>

                        <div class="col-md-12 mt-3 test-center">
                            <input type='submit' class="btn btn-primary btn-sm" value="Add student" />
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Update User Modal -->
    <div class="modal fade" id="updateuser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body update_body" id="update_body">
                    <form action="{{ url('/update') }}" method="post">
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <div class="col-md-12">
                            <label>Name</label>
                            <input type='text' class="form-control" value="" name='stud_name' />
                        </div>

                        <div class="col-md-12 mt-3 test-center">
                            <input type='submit' class="btn btn-primary btn-sm" value="Add student" />
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Bootstrap Js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>

    <script type="text/javascript">
        function delt(getid) {
            var id = getid;
            var confrm = confirm("Are you sure want to delete");
            if (confrm == true) {
                $.ajax({
                    url: '/delete',
                    type: 'POST',
                    data: {
                        id,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        // alert(response);
                        $('#delmsg').html(response);
                        setTimeout(() => {
                            location.reload();
                        }, 2000);
                        // Handle success response
                    },
                    error: function(xhr, status, error) {
                        console.log(error);
                        // Handle error response
                    }
                })
            }
        }

        function updateUser(getid) {
            var id = getid;
            // $.ajax({
            //     url: '/get_modal_data',
            //     type: 'POST',
            //     data: {
            //         id: id,
            //         _token: '{{ csrf_token() }}'
            //     },
            //     success: function(response) {
            //         $('#update_body').html(response);
            //         $('#updateuser').modal('show');
            //     },
            //     error: function(xhr, status, error) {
            //         console.log(error);
            //         // Handle error response
            //     }
            // });
            $('#updateuser').modal('show');
        }
        // $('.deleteuser').on('click', function() {
        //     var id = $('.deleteuser').val();
        //     alert(id);
        // });
    </script>

</body>

</html>